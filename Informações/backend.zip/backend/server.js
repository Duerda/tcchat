const express = require("express");
const cors = require("cors");

const app = express();

app.use(cors());
app.use(express.json());

const authRoutes = require("./routes/auth");
app.use("/auth", authRoutes)

app.listen(3000, () => {
    console.log("Servidor rodando na porta 3000: http://localhost:3000/")
})