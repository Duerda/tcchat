// api/db.js
import mysql from 'mysql2/promise';

// esse aqui é um exemplo
const pool = mysql.createPool({
  host: process.env.DB_HOST || 'seu-host.com',
  user: process.env.DB_USER || 'seu_usuario',
  password: process.env.DB_PASSWORD || 'sua_senha',
  database: process.env.DB_NAME || 'tcchat_db',
  waitForConnections: true,
  connectionLimit: 10,
  queueLimit: 0
});

export default pool;
