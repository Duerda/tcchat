// api/login.js
import pool from './db.js';

export default async function handler(req, res) {
  if (req.method === 'POST') {
    const { email, senha, tipoEsperado } = req.body;

    // Validação básica
    if (!email || !senha || !tipoEsperado) {
      return res.status(400).json({ error: 'E-mail, senha e tipo de usuário são obrigatórios.' });
    }

    // Validação de domínio de e-mail institucional
    const isAluno = email.endsWith('@Aluno.cps.sp.gov.br');
    const isProfessor = email.endsWith('@Professor.cps.sp.gov.br');

    if (tipoEsperado === 'Aluno' && !isAluno) {
      return res.status(403).json({ error: 'Acesso negado. Use um e-mail @Aluno.cps.sp.gov.br' });
    }

    if (tipoEsperado === 'Professor' && !isProfessor) {
      return res.status(403).json({ error: 'Acesso negado. Use um e-mail @Professor.cps.sp.gov.br' });
    }

    try {
      // Buscar usuário no banco de dados SQL
      const [users] = await pool.execute(
        'SELECT * FROM Usuarios WHERE email = ? AND senha = ? AND tipo = ?',
        [email, senha, tipoEsperado]
      );

      if (users.length === 0) {
        return res.status(401).json({ error: 'E-mail ou senha incorretos, ou usuário não cadastrado.' });
      }

      const user = users[0];

      //Retornar sucesso e dados básicos do usuário
      return res.status(200).json({
        message: 'Login realizado com sucesso!',
        user: {
          id: user.id,
          nome: user.nome,
          email: user.email,
          tipo: user.tipo
        }
      });
    } catch (error) {
      console.error('Erro ao realizar login no banco:', error);
      return res.status(500).json({ error: 'Erro interno ao processar o login.' });
    }
  } else {
    res.setHeader('Allow', ['POST']);
    res.status(405).end(`Method ${req.method} Not Allowed`);
  }
}
