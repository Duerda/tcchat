// api/cadastro.js
import pool from './db.js';

export default async function handler(req, res) {
  if (req.method === 'POST') {
    const { nome, email, senha, codigo } = req.body;

    // Validação básica
    if (!nome || !email || !senha || !codigo) {
      return res.status(400).json({ error: 'Todos os campos são obrigatórios.' });
    }

    // Validação de domínio de e-mail institucional
    const isAluno = email.endsWith('@Aluno.cps.sp.gov.br');
    const isProfessor = email.endsWith('@Professor.cps.sp.gov.br');

    if (!isAluno && !isProfessor) {
      return res.status(400).json({ error: 'E-mail institucional inválido. Use @Aluno.cps.sp.gov.br ou @Professor.cps.sp.gov.br' });
    }

    const tipoUsuario = isAluno ? 'Aluno' : 'Professor';

    try {
      // Verificar se o e-mail já está cadastrado
      const [existingUser] = await pool.execute(
        'SELECT id FROM Usuarios WHERE email = ?',
        [email]
      );

      if (existingUser.length > 0) {
        return res.status(409).json({ error: 'Este e-mail já está cadastrado.' });
      }

      // Inserir o novo usuário no banco de dados SQL
      const query = 'INSERT INTO Usuarios (nome, email, senha, codigo, tipo) VALUES (?, ?, ?, ?, ?)';
      const values = [nome, email, senha, codigo, tipoUsuario];
      
      const [result] = await pool.execute(query, values);

      console.log(`Novo ${tipoUsuario} cadastrado com ID:`, result.insertId);

      return res.status(201).json({ 
        message: 'Cadastro realizado com sucesso!',
        user: { id: result.insertId, nome, email, tipo: tipoUsuario }
      });
    } catch (error) {
      console.error('Erro ao cadastrar no banco:', error);
      return res.status(500).json({ error: 'Erro interno ao salvar no banco de dados.' });
    }
  } else {
    res.setHeader('Allow', ['POST']);
    res.status(405).end(`Method ${req.method} Not Allowed`);
  }
}
