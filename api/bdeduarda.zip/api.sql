CREATE DATABASE IF NOT EXISTS tcchat_db;
USE tcchat_db;

CREATE TABLE IF NOT EXISTS Usuarios (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(255) NOT NULL,
    email VARCHAR(255) UNIQUE NOT NULL,
    senha VARCHAR(255) NOT NULL,
    codigo VARCHAR(50),
    tipo ENUM("Aluno", "Professor") NOT NULL
);